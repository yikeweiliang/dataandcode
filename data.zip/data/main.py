import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats

plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']  
plt.rcParams['axes.unicode_minus'] = False  

plt.figure(figsize=(10, 6), dpi=100)  

pi = 3.141
d = 1e-3
I = 1e-4
B = 0.402
mu = 480
c1 = 25 * pi * d / (0.6931 * I)
c2 =100 * d / (I * B)

q = 1.6e-19


def data_fill(data):
    data['(V1+V2)'] = data['V1'] + data['V2']
    data['-(V1+V2)'] = data['-V1'] + data['-V2']
    data['Rho_Omegacm'] = c1 * (data['(V1+V2)'] - data['-(V1+V2)'])
    data['DeltaV3+'] = data['V3+B'] - data['V3+0']
    data['DeltaV3-'] = data['V3-B'] - data['V3-0']
    data['VH'] = (data['DeltaV3+'] + data['DeltaV3-']) / 2
    data['RH_1e4cm3'] = c2 * data['VH']
    data['T_rev'] = 1000 / (273.16 + data['样品温度'])
    data['T_log'] = np.log(273.16 + data['样品温度'])
    data['ln_rho'] = np.log(data['Rho_Omegacm'])
    data['ln_RH'] = np.log(np.abs(data['RH_1e4cm3']))
    data['ln_mu_p'] = np.log(mu * 3704 / data['Rho_Omegacm'])
    data['T'] = 273 + data['样品温度']
    data['b'] = 16 / (data['样品温度'] ** 0.3)
    data['p'] = ((1 / (q * 2.58e8 * (data['T'] ** (-2.318)) * data['Rho_Omegacm'])) + data['b'] * 3.36e12) / (data['b'] + 1)
    data['n'] = ((1 / (q * 2.58e8 * (data['T'] ** (-2.318)) * data['Rho_Omegacm'])) - 3.36e12) / (data['b'] + 1)
    data['lnp'] = np.log(data['p'])
    data['lnnp_T3'] = np.log(data['p'] * data['n'] / data['T'] ** 3)
    return data


data = pd.read_csv(r'近代物理实验\第一周-实验报告\data\data.csv')
data_mu = pd.read_csv(r'近代物理实验\第一周-实验报告\data\data_mu.csv')
data_lnpn = pd.read_csv(r'近代物理实验\第一周-实验报告\data\data_lnnpt.csv')
data_filled = data_fill(data)
data_filled.to_csv(r'近代物理实验\第一周-实验报告\data\data_filled.csv')

plt.plot(data_filled['T_rev'], data_filled['ln_rho'], label='ln_rho-1000/T', color='blue', linewidth=2, linestyle='-', marker='o', markersize=4)

plt.title('ln_rho-1/T')
plt.xlabel('X轴')
plt.ylabel('Y轴')
plt.legend()  
plt.grid(True, alpha=0.3)  
plt.show()

plt.plot(data_filled['T_rev'], data_filled['ln_RH'], label='ln_RH-1000/T', color='blue', linewidth=2, linestyle='-', marker='o', markersize=4)

plt.title('ln_RH-1/T')
plt.xlabel('X轴')
plt.ylabel('Y轴')
plt.legend()  
plt.grid(True, alpha=0.3)  
plt.show()

plt.plot(data_filled['T_log'], data_filled['ln_mu_p'], label='ln_mu_p-lg T', color='blue', linewidth=2, linestyle='-', marker='o', markersize=4)

plt.title('ln_mu_p-lg T')
plt.xlabel('X轴')
plt.ylabel('Y轴')
plt.legend()  
plt.grid(True, alpha=0.3)  
plt.show()

plt.plot(data_filled['T_rev'], data_filled['lnp'], label='lnp-1000/T', color='blue', linewidth=2, linestyle='-', marker='o', markersize=4)

plt.title('lnp-1000/T')
plt.xlabel('X轴')
plt.ylabel('Y轴')
plt.legend()  
plt.grid(True, alpha=0.3)  
plt.show()

plt.plot(data_filled['T_rev'], data_filled['lnnp_T3'], label='ln_npt-1000/T', color='blue', linewidth=2, linestyle='-', marker='o', markersize=4)

plt.title('lnnp-T3-1/T')
plt.xlabel('X轴')
plt.ylabel('Y轴')
plt.legend()  
plt.grid(True, alpha=0.3)  
plt.show()

slope, intercept, r_value, p_value, std_err = stats.linregress(data_mu['tlog'], data_mu['mulog'])

# 创建拟合直线
fit_line = slope * data_mu['tlog'] + intercept

# 创建图形
plt.figure(figsize=(10, 6))

# 绘制原始数据点
plt.scatter(data_mu['tlog'], data_mu['mulog'], color='blue', label='原始数据', alpha=0.7)

# 绘制拟合直线
plt.plot(data_mu['tlog'], fit_line, color='red', label=f'拟合直线: y = {slope:.2f}x + {intercept:.2f}')

# 添加图例
plt.legend()

# 添加标题和标签
plt.title('线性拟合结果')
plt.xlabel('X 值')
plt.ylabel('Y 值')

# 在图上标注斜率和截距信息
text_str = f'斜率: {slope:.3f}\n截距: {intercept:.3f}\nR^2: {r_value**2:.3f}'
plt.text(0.05, 0.95, text_str, transform=plt.gca().transAxes, fontsize=12,
         verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))

# 添加网格
plt.grid(True, alpha=0.3)

# 显示图形
plt.tight_layout()
plt.show()

# 打印拟合结果
print(f"斜率: {slope:.4f}")
print(f"截距: {intercept:.4f}")
print(f"R^2: {r_value**2:.4f}")
print(f"标准误差: {std_err:.4f}")




slope, intercept, r_value, p_value, std_err = stats.linregress(data_lnpn['T_rev'], data_lnpn['lnnpt3'])

# 创建拟合直线
fit_line = slope * data_lnpn['T_rev'] + intercept

# 创建图形
plt.figure(figsize=(10, 6))

# 绘制原始数据点
plt.scatter(data_lnpn['T_rev'], data_lnpn['lnnpt3'], color='blue', label='原始数据', alpha=0.7)

# 绘制拟合直线
plt.plot(data_lnpn['T_rev'], fit_line, color='red', label=f'拟合直线: y = {slope:.2f}x + {intercept:.2f}')

# 添加图例
plt.legend()

# 添加标题和标签
plt.title('线性拟合结果')
plt.xlabel('X 值')
plt.ylabel('Y 值')

# 在图上标注斜率和截距信息
text_str = f'斜率: {slope:.3f}\n截距: {intercept:.3f}\nR^2: {r_value**2:.3f}'
plt.text(0.05, 0.95, text_str, transform=plt.gca().transAxes, fontsize=12,
         verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))

# 添加网格
plt.grid(True, alpha=0.3)

# 显示图形
plt.tight_layout()
plt.show()

# 打印拟合结果
print(f"斜率: {slope:.4f}")
print(f"截距: {intercept:.4f}")
print(f"R^2: {r_value**2:.4f}")
print(f"标准误差: {std_err:.4f}")

